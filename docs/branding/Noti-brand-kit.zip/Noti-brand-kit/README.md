# Noti — little ideas welcome.

Meet Doti, Noti’s little lavender ink companion.

Open **Noti-brand-guide.html** for the portable visual guide, or read **Noti-brand-guide.pdf**.

- **doti.png**: full transparent mascot illustration.
- **vectors-and-colors/noti-wordmark.svg**: outlined wordmark; no font installation needed.
- **vectors-and-colors/noti-app-icon.svg**: compact vector icon preview.
- **vectors-and-colors/palette.json**: the brand colors.
- **fonts/**: actual static Nunito 400, 500, 600, 700 and 800 fonts with their correct style names.
- **android/**: adaptive launcher icon resources, including a monochrome mark. Copy these folders into your Android resources directory.
- **Nunito-OFL.txt**: the SIL Open Font License for the bundled typeface.

Use pastels for illustrations and surfaces, charcoal for text, and plum for primary actions. Keep the canvas quiet. Doti belongs in welcoming moments; errors, saving and destructive actions always use clear language.

The original full mascot was created with image generation for this identity. The compact launcher mark is a separate vector interpretation. All app source and integration notes are in the Noti repository’s docs/branding directory.
